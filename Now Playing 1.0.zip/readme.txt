
FREE APP

Created by WebIntoApp.com on Saturday 3rd of August 2024 12:47:53 AM.

Release APK & App Bundle (AAB) ready to be submitted to Google Play Store 
and to any other APK / AAB store over the internet.

-------------------------------------
App ID:			402636
App Key:		vnLKWYKwTahWJcebGPuimsQMNrcbggyQ
App Name:		Now Playing
App Version:	1.0
Package:		com.thefatpotato115.nowplaying
Mode:			Free App
-------------------------------------

Your free app is ready, you can now publish it to the 
google play store and to any apk app store on the internet.

-------------------------------------
Please note, your app is under a FREE mode, you can always 
convert it to your own dedicated and branded mobile app for 
Android and iOS with all the premium features at:

https://www.webintoapp.com/author/apps/402636/edit?cmd=app-switcher

-------------------------------------
Here are some useful links:
-------------------------------------

You can edit your app at:
https://www.webintoapp.com/author/apps

Get installs statistics at:
https://www.webintoapp.com/author/stats?appid=402636

The Author Area:
https://www.webintoapp.com/author/dashboard

-------------------------------------
WebIntoApp.com Team.
https://www.webintoapp.com
-------------------------------------
